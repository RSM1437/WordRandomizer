import boto3
import json

db_client = boto3.client('dynamodb')
table_name = 'DictionaryData_MW_2'


def lambda_handler(event, context):
    definitions = load_from_db()
    return {
        'statusCode': 200,
        'body': json.dumps(definitions),
        'size': len(definitions),
    }


def load_from_db():
    data = db_client.scan(TableName=table_name)
    definitions = {}
    for item in data['Items']:
        word = item['word']['S']
        definitions[word] = {}
        definitionsJson = item['definitions']['S']
        definitions[word] = json.loads(definitionsJson)
    return definitions
